import React from 'react';

const Explore = () => <h2>Explore</h2>

export default Explore;